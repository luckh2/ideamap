#!/usr/bin/env python
#
import cgi
import datetime
import logging 
import urllib
import  base64, zlib, re

from google.appengine.ext import db
from google.appengine.ext import webapp
from google.appengine.ext.webapp import util as gu
from google.appengine.ext.webapp import template
from google.appengine.api import urlfetch

from django.utils import simplejson   


class MainHandler(webapp.RequestHandler):

  def myError(self, status, description, encodeResponse):
    # header
    self.response.out.write('HTTP/1.1 %d %s\r\n' % (status, description))
    self.response.out.write('Server: %s\r\n' % self.Software)
    self.response.out.write('Content-Type: text/html\r\n')
    self.response.out.write('\r\n')
    # body
    content = '<h1>Fetch Server Error</h1><p>Error Code: %d<p>Message: %s' % (status, description)
    if encodeResponse == 'base64':
      self.response.out.write(base64.b64encode(content))
    elif encodeResponse == 'compress':
      self.response.out.write(zlib.compress(content))
    else:
      self.response.out.write(content)

  def get(self):
  
    form = cgi.FieldStorage() 
    question = form.getvalue('question')
    data=form.getvalue('data')
    
    if question is None and data is None:
      html = open("dblp.html", "r")
      for line in html:
        self.response.out.write(line),
    elif question is not None: 
      payload = dict(sparqlquery=urllib.quote(question))
      page=template.render('dblp_.html', payload)
      self.response.out.write(page)

    else:
      result_sparql=self.process_sparql(data)
      result_geo=self.process_geo(result_sparql)
      
      resultstr="{\"items\": [ "
      for i in range(len(result_geo)):
        resultstr=resultstr+" { "+ "\"label\"" + ":" + "\"" + result_geo[i]["label"]["value"]+ "\"" +" , "
        resultstr=resultstr+ "\"conference\"" + ":" + "\"" + result_geo[i]["confname"]["value"]+ "\"" +" , "
        resultstr=resultstr+ "\"year\"" + ":" + "\"" + result_geo[i]["year"]["value"]+ "\"" +" , "
        resultstr=resultstr+ "\"latlng\"" + ":" + "\"" + result_geo[i]["latlng"]+ "\"" +" },\n"
      resultstr=resultstr[:-2]+" \n]\n}"
      #resultstr=simplejson.dumps(result_geo)
      self.response.headers['Content-Type'] = 'application/json; charset=utf-8'
      self.response.out.write(resultstr)
        
  def process_sparql(self, question):
    query_sparql ="""select * from sparql.search where query="PREFIX dcterms: <http://purl.org/dc/terms/>
PREFIX dc: <http://purl.org/dc/elements/1.1/>
PREFIX swrc: <http://swrc.ontoware.org/ontology#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?label ?year ?confname
WHERE {
?paper dc:title ?label.
?paper dcterms:issued ?year.
?paper rdf:type swrc:InProceedings.
?paper dcterms:partOf  ?conf.
?conf rdfs:label ?confname.
FILTER (regex(?label, '%s', 'i')) 
}
ORDER BY DESC(?year)
LIMIT 20
" and service="http://dblp.l3s.de/d2r/sparql"
""" % question
    
    query=urllib.quote(query_sparql)
    #&diagnostics=false&env=http%%3A%%2F%%2Fdatatables.org%%2Falltables.env&callback=
    url = "http://67.195.132.238/v1/public/yql?q=%s&format=json&diagnostics=false&env=store%%3A%%2F%%2Fdatatables.org%%2Falltableswithkeys" % query
    #response = simplejson.loads(urlfetch.fetch(url, follow_redirects=True, headers={'Content-Type':'application/json; charset=utf-8'}, allow_truncated=False, deadline=10).content)["query"]
    response = simplejson.loads(urlfetch.fetch(url,deadline=10).content)["query"]
    if response is None or int(response["count"]) == 0:
      return None
    return response["results"]["sparql"]["result"]

  def process_geo(self, result_sparql):
    query="select * from yql.query.multi where queries=\""
    subquery=""
    for i in range(len(result_sparql)):
      confname=result_sparql[i]["confname"]["value"]
      confname=confname.replace("'","")
      confname=confname.replace("\"","")
      subquery=subquery+"select centroid from geo.places where text='"+confname+"' limit 1;"
    subquery=subquery[:-1]
    query_geo=query+subquery+"\""
    
    #query_geo="""select centroid from geo.places where text="%s" """% confname
    query=urllib.quote(query_geo)
    url= "http://67.195.132.238/v1/public/yql?q=%s&format=json&diagnostics=false&env=http%%3A%%2F%%2Fdatatables.org%%2Falltables.env&callback=" % query
    response = simplejson.loads(urlfetch.fetch(url, deadline=10).content)["query"]
    
    assert len(response["results"]["results"]) == len(result_sparql)

    for i in range(len(response["results"]["results"])):
      lat=response["results"]["results"][i]["place"]["centroid"]["latitude"]
      lng=response["results"]["results"][i]["place"]["centroid"]["longitude"]
      latlng=lat+","+lng
      result_sparql[i]["latlng"]=latlng
    return result_sparql
  
      
def main():
  application = webapp.WSGIApplication([('/dblp', MainHandler)],
  debug=True)
  gu.run_wsgi_app(application)


if __name__ == '__main__':
  main()
