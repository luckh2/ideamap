﻿#!/usr/bin/env python
#-*- coding: utf-8 -*-
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import cgi
import datetime
import wsgiref.handlers
import urllib

from google.appengine.ext import db
from google.appengine.api import users
from google.appengine.ext import webapp
from google.appengine.ext.webapp import template
from google.appengine.ext.webapp import util
from google.appengine.api import mail 
from google.appengine.api import urlfetch

from django.utils import simplejson   


class MainHandler(webapp.RequestHandler):

  def get(self):
    form = cgi.FieldStorage() 
    question = form.getvalue('question')
    data=form.getvalue('data')
    
    if question is None and data is None:
      html = open("dblp.html", "r")
      for line in html:
        self.response.out.write(line),
    elif question is not None: 
      payload = dict(sparqlquery=urllib.quote(question))
      page=template.render('dblp_.html', payload)
      self.response.out.write(page)

    else:
      result_sparql=self.process_sparql(data)
      result_geo=self.process_geo(result_sparql)
      
      resultstr="{\"items\": [ "
      for i in range(len(result_geo)):
        resultstr=resultstr+" { "+ "\"label\"" + ":" + "\"" + result_geo[i]["label"]["value"]+ "\"" +" , "
        resultstr=resultstr+ "\"conference\"" + ":" + "\"" + result_geo[i]["confname"]["value"]+ "\"" +" , "
        resultstr=resultstr+ "\"year\"" + ":" + "\"" + result_geo[i]["year"]["value"]+ "\"" +" , "
        resultstr=resultstr+ "\"latlng\"" + ":" + "\"" + result_geo[i]["latlng"]+ "\"" +" },\n"
      resultstr=resultstr[:-2]+" \n]\n}"
      #resultstr=simplejson.dumps(result_geo)
      self.response.headers['Content-Type'] = 'application/json; charset=utf-8'
      self.response.out.write(resultstr)
        
  def process_sparql(self, question):
    query_sparql ="""select * from sparql.search where query="PREFIX dcterms: <http://purl.org/dc/terms/>
PREFIX dc: <http://purl.org/dc/elements/1.1/>
PREFIX swrc: <http://swrc.ontoware.org/ontology#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?label ?year ?confname
WHERE {
?paper dc:title ?label.
?paper dcterms:issued ?year.
?paper rdf:type swrc:InProceedings.
?paper dcterms:partOf  ?conf.
?conf rdfs:label ?confname.
FILTER (regex(?label, '%s', 'i')) 
}
ORDER BY DESC(?year)
LIMIT 20
" and service="http://dblp.l3s.de/d2r/sparql"
""" % question
    
    query=urllib.quote(query_sparql, safe=":/?&=")
    #&diagnostics=false&env=http%%3A%%2F%%2Fdatatables.org%%2Falltables.env&callback=
    #url = "http://67.195.132.238/v1/public/yql?q=%s&format=json&diagnostics=false&env=store%%3A%%2F%%2Fdatatables.org%%2Falltableswithkeys" % query
    url = "http://query.yahooapis.com/v1/public/yql?q=%s&format=json&diagnostics=false&env=store%%3A%%2F%%2Fdatatables.org%%2Falltableswithkeys" % query
    #response = simplejson.loads(urlfetch.fetch(url, follow_redirects=True, headers={'Content-Type':'application/json; charset=utf-8'}, allow_truncated=False, deadline=10).content)["query"]
    response = simplejson.loads(urlfetch.fetch(url).content)["query"]
    if response is None or int(response["count"]) == 0:
      return None
    return response["results"]["sparql"]["result"]

  def process_geo(self, result_sparql):
    query="select * from yql.query.multi where queries=\""
    subquery=""
    for i in range(len(result_sparql)):
      confname=result_sparql[i]["confname"]["value"]
      confname=confname.replace("'","")
      confname=confname.replace("\"","")
      subquery=subquery+"select centroid from geo.places where text='"+confname+"' limit 1;"
    subquery=subquery[:-1]
    query_geo=query+subquery+"\""
    
    #query_geo="""select centroid from geo.places where text="%s" """% confname
    query=urllib.quote(query_geo, safe=":/?&=")
    url= "http://query.yahooapis.com/v1/public/yql?q=%s&format=json&diagnostics=false&env=http%%3A%%2F%%2Fdatatables.org%%2Falltables.env&callback=" % query
    response = simplejson.loads(urlfetch.fetch(url).content)["query"]
    
    assert len(response["results"]["results"]) == len(result_sparql)

    for i in range(len(response["results"]["results"])):
      lat=response["results"]["results"][i]["place"]["centroid"]["latitude"]
      lng=response["results"]["results"][i]["place"]["centroid"]["longitude"]
      latlng=lat+","+lng
      result_sparql[i]["latlng"]=latlng
    return result_sparql


def main():
  application = webapp.WSGIApplication([('/', MainHandler), ('/dblp', MainHandler)],
                                       debug=True)
  util.run_wsgi_app(application)


if __name__ == '__main__':
  main()




